---
name: qa-approval-probe
description: Use for harmless manual QA approval probes.
---

This is a harmless manual QA artifact.
