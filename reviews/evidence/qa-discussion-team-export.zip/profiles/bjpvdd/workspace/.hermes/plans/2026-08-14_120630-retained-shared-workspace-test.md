# Retained Shared-Workspace Discussion Test Plan

> **For Hermes:** Execute the three worker stages in dependency order, preserving the shared scratchpad at every stage.

**Goal:** Run a retained shared-workspace discussion in which Primary proposes BLUE, Researcher challenges with GREEN, and Reviewer resolves the disagreement without losing any existing data.

**Architecture:** All stages use the same shared run workspace and the same file, `shared/qa-team-scratchpad.md`. Each worker must read before writing, append exactly one stage marker line, and preserve every prior line. The final reviewer validates the accumulated record and states the resolution.

**Tech Stack:** Plain-text Markdown scratchpad and worker-stage instructions.

---

## Execution order and worker guidance

### Stage 1 — `qa-2026-08-14-primary-agent` (primary-planner)

1. Identify the shared run workspace; do not create a separate private scratchpad.
2. Check whether `shared/qa-team-scratchpad.md` already exists.
3. Create the file only if absent; if present, preserve all existing lines and data.
4. Append a line containing the exact marker `PRIMARY` (never truncate or rewrite existing content).
5. Add a concise proposal explaining: use `BLUE`.
6. Verify the file still contains all pre-existing content, the exact `PRIMARY` marker, and the BLUE proposal before handing off.

**Handoff requirement:** Stage 2 may start only after Stage 1 confirms the file path and successful append.

### Stage 2 — `qa-2026-08-14-researcher` (researcher)

1. Read the same `shared/qa-team-scratchpad.md` from the shared run workspace.
2. Verify the exact `PRIMARY` marker and BLUE proposal are present; stop and report a dependency failure if not.
3. Append a line containing the exact marker `RESEARCHER`; preserve every existing line and all existing data.
4. Append a concise challenge arguing that `GREEN` is better than `BLUE`, explicitly discussing the disagreement.
5. Re-read and verify that PRIMARY content remains unchanged and both markers plus the GREEN argument are present.

**Handoff requirement:** Stage 3 may start only after Stage 2 confirms both markers and the appended GREEN challenge.

### Stage 3 — `qa-2026-08-14-reviewer` (reviewer)

1. Read the same shared scratchpad.
2. Verify the exact `PRIMARY` and `RESEARCHER` markers and their associated BLUE/GREEN discussion.
3. Append a line containing the exact marker `REVIEWER`; preserve every prior line and all existing data.
4. Review the BLUE-versus-GREEN disagreement and append a reasoned resolution recommending one choice.
5. Re-read the complete file and confirm that all original content and the exact markers `PRIMARY`, `RESEARCHER`, and `REVIEWER` remain.

## Acceptance criteria

- All three stages execute in dependency order.
- Every stage reads before appending and uses the identical shared workspace path.
- No line or existing data is deleted, overwritten, or reordered.
- The scratchpad contains the exact markers `PRIMARY`, `RESEARCHER`, and `REVIEWER`.
- The discussion explicitly covers BLUE versus GREEN.
- Reviewer records a resolved choice with reasons.
- Final report includes the absolute shared scratchpad path and the exact markers found, in file order.

## Validation and final report

After Stage 3, inspect the complete file rather than relying on worker summaries. Confirm marker count and order programmatically or by exact text inspection. Report:

- Shared scratchpad path: `shared/qa-team-scratchpad.md` resolved under the shared run workspace.
- Exact markers found: `PRIMARY`, `RESEARCHER`, `REVIEWER`.
- Brief resolution recorded by Reviewer.
- Any pre-existing lines preserved, if applicable.

Do not claim completion unless the final read verifies all acceptance criteria.
